﻿using KonusarakOgrenn.BusinessLayer.Infrastructure;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using KonusarakOgrenn.BusinessLayer.Helper;

namespace KonusarakOgrenn.BusinessLayer.Repository
{
    public class GenericRepository<T> : IBaseRepository<T> where T:class, new()
    {
        readonly OrmHelper helper;
        public IDapperContext Context { get; set; }
        private readonly string tableName;
        public GenericRepository( )
        {
           
            this.tableName = typeof(T).Name;
            this.Context = new DapperContext();
            helper = new OrmHelper(typeof(T));
        }      


        public async Task<int> DeleteRowAsync(int id)
        {
            using (var Conn = Context.GetOpenConnection())
            {                
                return await Conn.ExecuteAsync($"DELETE FROM {tableName} WHERE Id=@Id", new { Id = id });
            }
        }
        
        public async Task<IEnumerable<T>> GetAllAsync()
        {
            using (var Conn = Context.GetOpenConnection())
            {
                var m= await Conn.QueryAsync<T>($"SELECT * FROM {tableName}");
                return m;
            }
        }

        public async Task<T> GetUser(object username, object password)
        {
            using (var Conn = Context.GetOpenConnection())
            {
                var model= await Conn.QueryFirstOrDefaultAsync<T>($"Select * from {tableName} WHERE userName=@userName AND password=@password", new Dictionary<string, object> { { "userName", username } ,{"password",password } });
                return model;
            }
        }
        public async Task<T> GetById(object param)
        {
            using (var Conn = Context.GetOpenConnection())
            {
                var model = await Conn.QueryFirstOrDefaultAsync<T>($"Select * from {tableName} WHERE Id=@id", new Dictionary<string, object> { { "id", param } });
                return model;
            }
        }
        public async Task<int> InsertAsync(T entity)
        {
            using (var Conn = Context.GetOpenConnection())
            {
                    var insertQuery = helper.GenerateInsertQuery();
                    var s= await Conn.QuerySingleAsync<int>(insertQuery, entity);
                    return s;                        
               
            }
        }
        public Task<T> QueryFirstOrDefaultAsync<Tentity>(string sql, Dictionary<string, object> param = null) where Tentity : class,new()
        {
            return Context.Connection.QueryFirstOrDefaultAsync<T>(sql, param);
        }

        public async Task<int> UpdateAsync(T entity)
        {
            using (var Conn=Context.GetOpenConnection())
            {
                var updateQuery = helper.GenerateUpdateQuery();
                return await Conn.ExecuteAsync(updateQuery,entity);
            }
        }

       

    }
  
}
