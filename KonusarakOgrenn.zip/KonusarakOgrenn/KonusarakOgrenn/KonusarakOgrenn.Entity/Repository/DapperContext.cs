﻿using KonusarakOgrenn.BusinessLayer.Infrastructure;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Text;

namespace KonusarakOgrenn.BusinessLayer.Repository
{
    public class DapperContext : IDapperContext
    {
        private readonly string _connectionString;


      
      
        public DapperContext()
        {
            var myBuilder = new SQLiteConnectionStringBuilder();
            myBuilder.DataSource = @"..\KonusarakOgrenn.Datam\Data\MyDatabase.db";
            _connectionString = myBuilder.ConnectionString;

        }

        private IDbConnection _connection;
        public IDbConnection Connection
        {
            get
            {
                if (_connection == null)
                {
                    _connection = new SQLiteConnection(_connectionString);
                }

                if (_connection.State == ConnectionState.Closed)
                {
                    _connection.Open();
                }
                return _connection;
            }

        }
        public string ConnectionString
        {
            get { return _connectionString; }
        }
        public void Dispose()
        {            

            if (_connection != null && _connection.State != ConnectionState.Closed)
                _connection.Close();
        }

        public SQLiteConnection GetOpenConnection()
        {

            var connection = new SQLiteConnection(_connectionString);
            
            connection.Open();
            return connection;
        }

      
    }
}
