﻿using KonusarakOgrenn.BusinessLayer.Infrastructure;
using KonusarakOgrenn.BusinessLayer.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace KonusarakOgrenn.BusinessLayer.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        public UnitOfWork()
        {

        }
        public Dictionary<Type, dynamic> repositories = new Dictionary<Type, dynamic>();


        public IBaseRepository<T> GetRepository<T>() where T : class, new()
        {

            if (repositories.ContainsKey(typeof(T)))
            {
                return repositories[typeof(T)] as IBaseRepository<T>;
            }
            IBaseRepository<T> repository = new GenericRepository<T>();
            repositories.Add(typeof(T), repository);

            return repository;

        }


    }
}