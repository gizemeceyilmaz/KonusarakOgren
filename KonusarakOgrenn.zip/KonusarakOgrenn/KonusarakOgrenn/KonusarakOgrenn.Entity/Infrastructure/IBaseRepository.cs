﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace KonusarakOgrenn.BusinessLayer.Infrastructure
{
    public interface IBaseRepository<T> where T:class,new()
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<int> DeleteRowAsync(int id);
        Task<T> GetById(object param);
        Task<T> GetUser(object param, object pasword);
        Task<int> UpdateAsync(T entity);
        Task<int> InsertAsync(T entity);
        Task<T> QueryFirstOrDefaultAsync<Tentity>(string sql, Dictionary<string, object> param = null) where Tentity : class, new();

    }
}
