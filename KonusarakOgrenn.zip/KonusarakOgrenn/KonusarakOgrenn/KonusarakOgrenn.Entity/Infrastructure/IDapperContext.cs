﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Text;

namespace KonusarakOgrenn.BusinessLayer.Infrastructure
{
 
        public interface IDapperContext : IDisposable
        {
            IDbConnection Connection { get; }          
            string ConnectionString { get; }
       
            SQLiteConnection GetOpenConnection();
        }
    
}
