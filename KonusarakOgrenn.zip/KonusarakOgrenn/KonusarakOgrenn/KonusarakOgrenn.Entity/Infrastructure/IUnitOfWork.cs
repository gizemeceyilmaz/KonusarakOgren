﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonusarakOgrenn.BusinessLayer.Infrastructure
{
    public interface IUnitOfWork
    {
        IBaseRepository<T> GetRepository<T>() where T : class, new();
    }
}
