﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using KonusarakOgrenn.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using KonusarakOgrenn.BusinessLayer.Infrastructure;
using KonusarakOgrenn.Datam.Data.Models;
using System.Data;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace KonusarakOgrenn.Web.Controllers
{

    public class HomeController : Controller
    {

        public IUnitOfWork unitOfWork;
        public HomeController(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

        }
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("isUserLogin") != "true")
            {
                TempData["message"] = "Bu sayfaya girmek icin once giris yapiniz";
                return RedirectToAction("Index", "Login", ViewBag.Mesaj);
            }
            var yazilar = await unitOfWork.GetRepository<Yazilar>().GetAllAsync();


            return View(yazilar);
        }
        [HttpPost]
        public async Task<IActionResult> SaveQuestion(int YaziId, string soru ,string[] answers, int trueanswer)
        {
            var sinav = new Sinavlar()
            {
                UserId = Convert.ToInt32(HttpContext.Session.GetString("Id")),
                YaziId = YaziId
            };
            var QuestionId = await unitOfWork.GetRepository<Sinavlar>().InsertAsync(sinav);

            Sorular sorular = new Sorular()
            {
                sinavid = QuestionId,
                cevap1 = answers[0],
                cevap2 = answers[1],
                cevap3 = answers[2],
                cevap4 = answers[3],
                Soru = soru,
                dogrucevap = answers[trueanswer - 1]
            };
            await unitOfWork.GetRepository<Sorular>().InsertAsync(sorular);
            //foreach (var item in question)
            //{
            //    item.sinavid = QuestionId;
            //    await unitOfWork.GetRepository<Sorular>().InsertAsync(item);
            //}
            return Redirect("/Home/Index");
        }
        public async Task<IActionResult> Sinavlarim()
        {
            var sinavlar = await unitOfWork.GetRepository<Sinavlar>().GetAllAsync();
            return View(sinavlar);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpPost]
        public async Task<string> GetYazi(int id)
        {
            var yazilar = await unitOfWork.GetRepository<Yazilar>().GetById(id);
            return yazilar.Yazi;
        }
    }
}
