﻿using KonusarakOgrenn.BusinessLayer.Infrastructure;
using KonusarakOgrenn.Datam.Data.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace KonusarakOgrenn.Web.Controllers
{
    public class LoginController : Controller
    {
        public IUnitOfWork unitOfWork;
        public LoginController(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

        }
        [HttpGet]
        public  IActionResult Index()
        {
            if (TempData["message"]!=null)            
                ViewBag.Mesaj = TempData["message"];            
        
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(User userAcount)
        {
            var kullanici =  await unitOfWork.GetRepository<User>().GetUser(userAcount.UserName,userAcount.Password);
            if (kullanici != null)
            {
                HttpContext.Session.SetString("isUserLogin", "true");
                HttpContext.Session.SetString("Id", kullanici.Id.ToString());
                return RedirectToAction("Index", "Home");
            }
                ViewBag.Mesaj = "Geçersiz Kullanıcı Adı veya Şifre";
                return View();
            
        }

        [HttpGet]
        public ActionResult Sigin()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> Sigin( User user)
        {
            try
            {
                await unitOfWork.GetRepository<User>().InsertAsync(user);
                ViewBag.Mesaj = "Uyelik isleminiz basariyla tamamlanmistir. Kullanici adi ve sifre ile giris yapabilirsiniz.";
                return RedirectToAction("Index", "Login");

            }
            catch (System.Exception)
            {

                ViewBag.Mesaj = "Uyelik isleminiz basarisizdir. tekrar deneyiniz";
                return View();

            }


        }
        [HttpGet]
        public ActionResult Logout()
        {
            HttpContext.Session.Clear();
            ViewBag.Mesaj = "Cikis yaptiniz";
            return RedirectToAction("Index", "Login");
        }

    }
}
