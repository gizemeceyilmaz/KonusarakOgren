﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonusarakOgrenn.Datam.Data.Models
{
    public class Sorular :IBaseEntity
    {
        public int Id { get; set; }
        public string Soru { get; set; }

        public string cevap1 { get; set; }
        public string cevap2 { get; set; }
        public string cevap3 { get; set; }
        public string cevap4 { get; set; }
        public int sinavid { get; set; }
        public string dogrucevap { get; set; }
    }
}
