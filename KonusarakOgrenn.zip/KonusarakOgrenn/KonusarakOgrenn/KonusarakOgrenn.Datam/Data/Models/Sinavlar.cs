﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KonusarakOgrenn.Datam.Data.Models
{
    public class Sinavlar :IBaseEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }

        public int YaziId { get; set; }
    }
}
